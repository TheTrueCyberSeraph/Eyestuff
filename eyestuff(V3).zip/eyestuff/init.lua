local eyestuff_path = minetest.get_modpath("eyestuff")
dofile(eyestuff_path.."/blockgen.lua")

minetest.register_node("eyestuff:eyeblock", {
    description = "Eyeblock",
    tiles = {
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png"
    },groups = {cracky = 1, level = 3}
})
minetest.register_node("eyestuff:circleblock", {
    description = "swirly",
    tiles = {
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png"
    },groups = {cracky = 1, level = 3},light_source = 14})

minetest.register_node("eyestuff:eyedust", {
	description = ("Eyedust"),
	tiles = {"eyestuff-eyedust.png"},
	groups = {crumbly = 3, falling_node = 1}, 	
	light_source = 3
})

minetest.register_node("eyestuff:eyestone",{
	description = ("Eyestone"),
	tiles = {"eyestuff-eyestone.png"},
	drop = "eyestuff:cobbled_eyestone",
	groups = {cracky = 1},
	light_source = 8
})
minetest.register_node("eyestuff:eyedirt", {
	description = ("Eyedirt"),
	tiles = {"eyestuff-eyedirt.png"},
	groups = {crumbly = 3, soil = 1},
	light_source = 6
})
minetest.register_node("eyestuff:cobbled_eyestone", {
	description = ("Cobbled Eyestone"),
	tiles = {"eyestuff-cobbled-eyestone.png"},
	groups = {cracky = 1},
	light_source = 5
})
minetest.register_node("eyestuff:eyegoo_source", {
	description = ("Eyegoo Source"),
	drawtype = "liquid",
	waving = 2,
	tiles = {
		{
			name = "eyestuff-eyegoo-source.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.0,
			},
		},
		{
			name = "eyestuff-eyegoo-source.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.0,
			},
		},
	},
	paramtype = "light",
	light_source = 12,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "eyestuff:eyegoo_flowing",
	liquid_alternative_source = "eyestuff:eyegoo_source",
	liquid_viscosity = 9,
	post_effect_color = {a = 191, r = 155, g = 155, b = 0},
	groups = {liquid = 1, flammable = 2},
})
minetest.register_node("eyestuff:eyegoo_flowing", {
	description = ("Flowing Eyegoo"),
	drawtype = "flowingliquid",
	waving = 2,
	tiles = {"eyestuff-eyegoo-flowing.png"},
	special_tiles = {
		{
			name = "eyestuff-eyegoo-flowing.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.3,
			},
		},
		{
			name = "eyestuff-eyegoo-flowing.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 3.3,
			},
		},
	},
	paramtype = "light",
	paramtype2 = "flowingliquid",
	light_source = 12,
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "eyestuff:eyegoo_flowing",
	liquid_alternative_source = "eyestuff:eyegoo_source",
	liquid_viscosity = 9,
	post_effect_color = {a = 191, r = 155, g = 155, b = 0},
	groups = {liquid = 1, not_in_creative_inventory = 1, flammable = 2},
})

minetest.register_tool("eyestuff:pick", {
	description = "Eye Pickaxe",
	inventory_image = "Swirlypick.png",
	tool_capabilities = {
		full_punch_interval = 0.01,
		max_drop_level = 88,
		groupcaps = {
			cracky = {
				times={[1]=1.0, [2]=1.0, [3]=0.50},
				uses = 200000,
				maxlevel = 10
			}
		},
		damage_groups = {fleshy = 1000, fire = 666},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_craft({
	type="shaped",
	output="eyestuff:pick",
	recipe={
		{"eyestuff:eyeblock","eyestuff:circleblock","eyestuff:eyeblock",},
		{"", "eyestuff:eyerod", "",},
		{"", "eyestuff:eyerod", "",}
	}
})
minetest.register_craftitem("eyestuff:eyerod",{
		description=("Rods of Eye"),
		inventory_image="eyestuff-eyerod.png"
	})
minetest.register_craft( {
	type = "shapeless",
	output = "eyestuff:eyerod 4",
	recipe = { "eyestuff:eyeblock" },
})
