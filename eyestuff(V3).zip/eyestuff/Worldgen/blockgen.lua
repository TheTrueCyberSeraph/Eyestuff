minetest.register_ore({
	ore_type = "scatter",
	ore = "eyestuff:circleblock",
	wherein = "default:stone",
	clust_scarcity = 8*8*8,
	clust_num_ores = 6,
	clust_size = 4,
	y_min = -5000,
	y_max = -1000,
})
minetest.register_ore({
	ore_type = "scatter",
	ore = "eyestuff:eyeblock",
	wherein = "default:stone",
	clust_scarcity = 8*8*8,
	clust_num_ores = 5,
	clust_size = 3,
	y_min = -5000,
	y_max = -1000,
})